#include<stdio.h>
int getopt(char[]);
int main()
{
    int type;
    while((type=getopt(s)) != EOF)
    {
        switch(type)
        {



